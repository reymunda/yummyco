npm install to install the app
npm start to start the app